# PromptCraft — Universal AI Prompt Writer

> Write perfect AI prompts for **any** provider — Claude, Gemini, Groq, GPT, OpenRouter, or your own custom API. Free, open source, runs entirely in your browser.

![PromptCraft Screenshot](https://via.placeholder.com/1200x600/080A0F/7B5EA7?text=PromptCraft)

## ✨ Features

- **Works with any AI API** — Claude, Gemini, Groq, GPT-4, OpenRouter (200+ models), or any OpenAI-compatible endpoint
- **Completely free options** — Google Gemini and Groq are 100% free with no credit card required
- **Zero server** — your API key stays in your browser's `localStorage`, calls go directly to the AI provider
- **Smart prompt generation** — returns a polished main prompt plus two meaningful variations
- **Prompt types** — General, Creative Writing, Coding, Research, Business, Marketing, Education, Image Gen
- **Tone & detail control** — Professional, Casual, Creative, Technical, Persuasive, Concise × Brief/Balanced/Detailed/Step-by-step
- **One-click copy** — copy the main prompt or any variation instantly
- **Responsive** — works on desktop and mobile
- **Open source** — MIT licensed, single HTML file deployable anywhere

---

## 🚀 Quick Start

### Option 1: Use directly
Download `index.html` and open it in any browser. That's it.

### Option 2: Clone & serve
```bash
git clone https://github.com/yourusername/promptcraft.git
cd promptcraft

# Serve locally (any static server works)
npx serve .
# or
python3 -m http.server 8080
```
Open `http://localhost:8080`

### Option 3: Deploy free
| Platform | How |
|----------|-----|
| **Netlify** | Drag the folder to [netlify.com/drop](https://netlify.com/drop) |
| **GitHub Pages** | Push to repo → Settings → Pages → Deploy from main |
| **Vercel** | `npx vercel` in the project folder |

---

## 🔑 Getting a Free API Key

| Provider | Free Tier | Get Key |
|----------|-----------|---------|
| **Google Gemini** | ✅ Free forever, no credit card | [aistudio.google.com](https://aistudio.google.com) |
| **Groq** | ✅ Free forever, ultra-fast | [console.groq.com](https://console.groq.com) |
| **OpenRouter** | ✅ 200+ models, many free | [openrouter.ai/keys](https://openrouter.ai/keys) |
| **Anthropic Claude** | 💳 $5 free credit on signup | [console.anthropic.com](https://console.anthropic.com) |
| **OpenAI GPT** | 💳 Paid, no free tier | [platform.openai.com](https://platform.openai.com/api-keys) |

---

## 🗂 Project Structure

```
promptcraft/
├── index.html          # Main HTML (entry point)
├── css/
│   └── style.css       # All styles + provider accent theming
├── js/
│   ├── providers.js    # Provider configs, endpoints, request builders
│   ├── app.js          # Core generation logic, chips, keyboard shortcuts
│   └── ui.js           # Modal, toast, status, key management
└── README.md
```

---

## ➕ Adding a New Provider

Edit `js/providers.js` and add a new entry to the `PROVIDERS` object:

```javascript
myProvider: {
  name: "My Provider",
  baseUrl: "https://api.myprovider.com/v1/chat/completions",
  keyPlaceholder: "key-…",
  keyPrefix: "key-",
  models: [
    { id: "my-model-v1", label: "My Model V1" },
  ],
  note: "Get your key at myprovider.com",
  buildRequest(apiKey, model, systemPrompt, userMsg) {
    return {
      url: this.baseUrl,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: {
        model, max_tokens: 1024,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user",   content: userMsg },
        ],
      },
    };
  },
  parseResponse(data) {
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content || "";
  },
},
```

Then add a button in `index.html` inside `#providerGrid`.

---

## 🔒 Privacy

- Your API key is stored in **`localStorage`** in your browser only
- API calls go **directly** from your browser to the AI provider — no proxy, no middleman
- No analytics, no tracking, no external scripts except Google Fonts

---

## 📄 License

MIT © 2026 — free to use, fork, and self-host.
